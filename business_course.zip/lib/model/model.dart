library model;

// part '.dart';

abstract class Model {
  String id;
}