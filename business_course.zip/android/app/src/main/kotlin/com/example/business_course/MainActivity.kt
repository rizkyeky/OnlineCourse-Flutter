package com.example.business_course

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
